<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Routing\Redirector;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use App\Models\Item;
use App\Models\Proyecto;
use App\Models\fotosproyecto;
use App\Models\HerramientaProyecto;
use App\Models\Herramientas;

class SoftwareSoulsController extends Controller{
    public function cargarSoftwareSouls()
    {
    return view('Principal.SoftwareSouls');
    }

    public function obtenerProyectos(Request $request){
        $filtro = $request->filtro;
    
        if (trim($filtro) == '') {
            // Si no hay filtro, devuelve los primeros 10 proyectos
            $proyectos = Proyecto::take(10)->get(['NombreP', 'DescripcionP', 'ID_Publicacion'])->toArray();
        } else {
            // Si hay filtro, realiza la búsqueda tanto en el nombre como en la descripción
            $proyectos = Proyecto::where('NombreP', 'LIKE', '%' . $filtro . '%')
                                 ->orWhere('DescripcionP', 'LIKE', '%' . $filtro . '%')
                                 ->get(['NombreP', 'DescripcionP', 'ID_Publicacion'])
                                 ->toArray();
        }
    
        return $proyectos;
    }
    public function proyecto($id){
        $proyecto = Proyecto::with('fotosproyecto', 'herramientaPublicaciones.Herramientas')->find($id);

        return view('Principal.Proyecto', ['proyecto' => $proyecto]);
    }
};
