<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>SoftwareSouls</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<link rel="icon" href="<?php echo e(asset('img/Mascot-Logo16.png')); ?>" />
<body>

    <?php echo $__env->make('Principal/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="center-div">
      <div class="izquierda">
        <img class="imgP" src="<?php echo e(asset('img/ImagenPrincipal.jpg')); ?>" alt="imgP"/>
      </div>

      <div class="derecha">
          <h1>SoftwareSouls: Innovación Tecnológica a tu Alcance</h1>
          <br>
          <p>Te ofrecemos soluciones tecnológicas adaptadas a tus necesidades y presupuesto.</p>
          <ul>
              <li>Experiencia Centrada en la Satisfacción del Usuario</li>
              <li>Optimización Empresarial a Través de la Tecnología</li>
              <li>Capacitación Personalizada y Soporte Continuo</li>
              <li>Consultoría Tecnológica Estratégica</li>
          </ul>
      </div>
    </div>
    <section id="nosotros"></section>
    <div class="center-div2">
        <div class="izquierda">
            <img class="imgP1" src="<?php echo e(asset('img/Mascot-Logo.png')); ?>" alt="imgP1"/>
        </div>
        <div class="derecha">
            <h1>Nosotros</h1>
            <br>
            Somos SoftwareSouls, una firma comprometida con la excelencia en el desarrollo de soluciones tecnológicas para potenciar tu negocio. Nos esforzamos por ofrecer servicios que transforman tu visión en realidad.
            <br>
            <h2>Misión</h2>
            <br>
            Facilitar el crecimiento y la eficiencia de nuestros clientes a través de soluciones tecnológicas de vanguardia. Nos dedicamos a comprender las necesidades únicas de cada cliente y a proporcionar servicios personalizados que impulsen su éxito a nuevas alturas.
        </div>
    </div>
    <section id="proceso"></section>
    <div class="center-div3">
        <div class="divs-arriba">
            <h1>PROCESO DE TRABAJO</h1>
        </div>
        <div class="divs-abajo">
            <div class="abajo">
                <h3>Definir objetivos y alcance</h3>
                <h1>~I~</h1>
                <div class="text nomovil">Identificar los resultados esperados, las funciones y características específicas que la aplicación debe tener, así como también los límites de tiempo y recursos disponibles para su realización.</div>
            </div>
            <div class="abajo">
                <h3>Diseño y esquemas</h3>
                <h1>~II~</h1>
                <div class="text nomovil">Desarrollar los diseños de la interfaz de usuario (UI) y los esquemas de navegación, que sirven como planos para la construcción del producto final.</div>
            </div>
            <div class="abajo">
                <h3>Programación Backend y front end</h3>
                <h1>~III~</h1>
                <div class="text nomovil">En el desarrollo de una aplicación web, la programación Backend se encarga de la parte que funciona "detrás de escena", como manejar la base de datos y las reglas de negocio, mientras que la programación Frontend se ocupa de lo que ves y con lo que interactúas en la pantalla, como los botones y formularios.</div>
            </div>
        </div>
        <div class="divs-abajo">
            <div class="abajo ">
                <h3>Despliegue</h3>
                <h1>~IV~</h1>
                <div class="text nomovil">Luego de la programación, se realiza el despliegue en el Hosting seleccionado para iniciar el funcionamiento esto implica, la configuración y la adaptación del servicio con la aplicación desarrollada.</div>
            </div>
            <div class="abajo">
                <h3>Monitoreo y soporte</h3>
                <h1>~V~</h1>
                <div class="text nomovil">Garantizar un funcionamiento sin problemas de tu aplicación web con nuestro servicio de Monitoreo y Soporte. Además, dedicado para ayudarte con cualquier pregunta o problema que puedas tener.</div>
            </div>
        </div>
    </div>
    <section id="proyectos"></section>
    <div class="center-div3 moviles">
        <div class="Moviles"><h1>Para ver nuestros proyectos visita nuestro sitio web, desde un computador.</h1></div>
        <div class="arriba nomovil">
            <h1>Proyectos</h1>
        </div>
        <div class="arriba nomovil"><h4>Descubre nuestra variedad de proyectos y encuentra inspiración para tus propias ideas. Explora nuestras creaciones y sumérgete en el mundo de la innovación.</h4></div>
        <div class="nomovil">
            Filtrar por nombre o descripción
            <input class="nomovil form-control" type="text" v-model="filtro" placeholder="Escribe aquí">
        </div>
        <table class="nomovil">
            <thead>
                <tr>
                    <th>Nombre del Proyecto</th>
                    <th>Descripción</th>
                    <th>Examinar</th>
                </tr>
            </thead>
            <tbody id="contenidoProyectos">
                <!-- Los proyectos se cargarán aquí -->
            </tbody>
        </table>
    </div>
    <section id="contactos"></section>
    <div class="center-div2">
        <div class="izquierda">
            <h1>Contacto</h1>
            <br>
            <h2>Información de contacto</h2>
            Email: brayan.monroy@softwaresouls.cl<br>
            Teléfono: +56 9 5649 1016
            <h2>Redes Sociales:</h2>
            <a href="https://www.linkedin.com/in/brayan-monroy-c/" target="_blank">
                <img class="imgP4" src="<?php echo e(asset('img/linkedin.png')); ?>" alt="imgP4"/>
            </a>
        </div>
        <div class="derecha">
            <div class="nomovil Moviles divmovil">
                <h1>Contacto:</h1><br>
            </div>
            <div class="nomovil Moviles divmovil">
                Email: brayan.monroy@softwaresouls.cl<br>
                Teléfono: +56 9 5649 1016<br>
            </div>
            <div class="nomovil Moviles divmovil">
                <a href="https://www.linkedin.com/in/brayan-monroy-c/" target="_blank">
                    <img class="imgP4" src="<?php echo e(asset('img/linkedin.png')); ?>" alt="imgP4"/>
                </a>
            </div>
            <h1>Deja tu mensaje</h1>
            <form class="contact-form" id="formEnviar">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input v-model="nombre" type="text" placeholder="Nombre" class="form-control" name="nombre" required>
                </div>
                <div class="form-group">
                    <input v-model="correo" type="email" placeholder="Correo electrónico" class="form-control" name="correo" required>
                </div>
                <div class="form-group">
                    <textarea v-model="mensaje" placeholder="Mensaje" class="form-control" name="mensaje" required></textarea>
                </div>
                <h1><button type="submit" class="bttn2">Enviar</button></h1>
            </form>
            <div id="sendEmail" class="sendEmail"><h4>Su mensaje fue enviado con éxito, alguien se pondrá en contacto contigo</h4></div>
        </div>
    </div>
    <footer>
        <div id="pie">
            <pie></pie>
        </div>
    </footer>
</body>
<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <p>SoftwareSouls</p>
            <p>&copy; 2024 Todos los derechos reservados.</p>
        </div>
    </div>
</footer>
</html>
<script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$('#contenidoProyectos').on('click', '.bttn2', function() {
    var idPublicacion = $(this).data('id');
    window.location.href = '/proyecto/' + idPublicacion;
});
$(document).ready(function() {
    function cargarProyectos(filtro) {
        $.ajax({
            url: '/obtener',
            type: 'GET',
            data: { filtro: filtro },
            success: function(response) {
                $('#contenidoProyectos').empty();
                if (response.length === 0) {
                    $('#contenidoProyectos').append('<tr><td colspan="3">No hay proyectos con tus especificaciones.</td></tr>');
                } else {
                    $.each(response, function(key, proyecto) {
                        $('#contenidoProyectos').append('<tr><td>' + proyecto.NombreP + '</td><td>' + proyecto.DescripcionP + '</td><td><button class="bttn2" data-id="' + proyecto.ID_Publicacion + '">Examinar</button></td></tr>');
                    });
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('#contenidoProyectos').append('<tr><td colspan="3">Error al cargar los proyectos.</td></tr>');
            }
        });
    }

    cargarProyectos('');

    $('#filtroProyecto').keyup(function() {
        var filtro = $(this).val();
        cargarProyectos(filtro);
    });
});


document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('formEnviar');
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault(); // Previene la recarga de la página

            // Recopilar los datos del formulario
            var nombre = document.querySelector('.contact-form input[name="nombre"]').value;
            var correo = document.querySelector('.contact-form input[name="correo"]').value;
            var mensaje = document.querySelector('.contact-form textarea[name="mensaje"]').value;

            // Crear un objeto FormData para enviar los datos del formulario
            var formData = new FormData();
            formData.append('nombre', nombre);
            formData.append('correo', correo);
            formData.append('mensaje', mensaje);

            // Verificar si el token CSRF está presente en el DOM
            var csrfToken = document.querySelector('meta[name="csrf-token"]');
            if (!csrfToken) {
                console.error('CSRF token not found. Make sure you have a meta tag with name="csrf-token" in your head element.');
                return;
            }

            // Realizar la solicitud AJAX
            fetch('/sendEmail', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-Requested-With': 'XMLHttpRequest', // Necesario para que Laravel identifique la solicitud AJAX
                    'X-CSRF-TOKEN': csrfToken.getAttribute('content') // Token CSRF
                },
            })
            .then(response => response.json())
            .then(data => {
                console.log('Success:', data);
                // Oculta el formulario y muestra el mensaje de éxito
                document.querySelector('.contact-form').style.display = 'none';
                document.getElementById('sendEmail').style.display = 'block';
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        });
    }
});



</script>



<style scoped>
    .footer {
        background-color: rgba(0, 0, 0, 0.808);
        color: #fff;
        padding: 20px 0;
    }
    
    .container {
        width: 80%;
        margin: 0 auto;
    }
    
    .footer-content {
        text-align: center;
    }
    </style>
    

<style >

    /* Estilos para el scrollbar en WebKit (Chrome, Safari) */
    ::-webkit-scrollbar {
    width: 12px; /* Ancho del scrollbar */
    }

    ::-webkit-scrollbar-thumb {
    background-color: rgba(36, 10, 10, 0.87); /* Color del thumb (la parte que puedes arrastrar) */
    border-radius: 6px; /* Bordes redondeados del thumb */
    }

    ::-webkit-scrollbar-track {
    background-color: #1e1e1e; /* Color del fondo del scrollbar (track) */
    }

    /* Estilos para el scrollbar en Firefox */
    body {
    scrollbar-color: rgba(36, 10, 10, 0.87) #1e1e1e; /* Color del thumb y track */
    scrollbar-width: thin; /* Ancho del scrollbar */
    }

</style>

<style scoped>
  h1{
      text-align: center;
  }
  h3{
      text-align: center;
  }
  .center-div {
    display: flex;
    position: block;
    margin: auto;
    margin-top: 100px;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 1200px;
    height: auto; /* Cambiado a 'auto' para permitir altura dinámica según contenido */
    background-color: rgba(36, 10, 10, 0.871);
    border-radius: 3px;
    display: flex;
    flex-direction: row; /* Mantenido 'row' para alinear los elementos en una fila */
    align-items: flex-start; /* Cambiado a 'flex-start' para alinear los elementos en la parte superior */
    justify-content: space-between; /* Distribuye los elementos a lo largo del eje principal con espacio entre ellos */
    margin-bottom: 2%;
  }
  .center-div2 {
      display: flex;
    position: block;
    margin: auto;
    margin-top: 100px;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 1200px;
    height: auto; /* Cambiado a 'auto' para permitir altura dinámica según contenido */
    background-color: rgba(36, 10, 10, 0.871);
    border-radius: 3px;
    display: flex;
    flex-direction: row; /* Mantenido 'row' para alinear los elementos en una fila */
    align-items: flex-start; /* Cambiado a 'flex-start' para alinear los elementos en la parte superior */
    justify-content: space-between; /* Distribuye los elementos a lo largo del eje principal con espacio entre ellos */
    margin-bottom: 2%;
  }
  .center-div3 {
    display: flex;
    position: block;
    margin: auto;
    margin-top: 100px;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 1200px;
    height: 325px; /* Cambiado a 'auto' para permitir altura dinámica según contenido */
    background-color: rgba(36, 10, 10, 0.87);
    border-radius: 3px;
    display: flex;
    flex-direction: row; /* Mantenido 'row' para alinear los elementos en una fila */
    align-items: flex-start; /* Cambiado a 'flex-start' para alinear los elementos en la parte superior */
    justify-content: space-between; /* Distribuye los elementos a lo largo del eje principal con espacio entre ellos */
    margin-bottom: 2%;
  }
  .izquierda {
    margin-right: 10px;
    margin-left: 13px;
    margin-bottom: 10px;
    margin-top: 16px;/* Agregado margen derecho para separar la izquierda de las derechas */
  }
  
  .derecha {
    width: 130%; /* Reducido el ancho para dejar espacio entre los divs de la derecha */
    margin-top: 10px;
    margin-right: 50px; /* Agregado margen superior para separar los divs de la derecha */
  }
  .imgP1 {
      max-width: 70%;
    height: auto;
    border-radius: 10px;
    border: 3px solid transparent; /* Asegura que haya espacio para el borde */
    transition: transform 0.3s ease;  /* Transición suave para el agrandamiento */
    background-color: rgba(247, 244, 244, 0.87); /* Color rojizo oscuro */
    filter: brightness(80%); /* Ajusta la luminosidad según sea necesario */
  }
  .imgP1:hover {
    transform: scale(1.1);  /* Aumenta el tamaño al 105% del original */
    border-color: rgba(0, 0, 0, 0.5); /* Color y opacidad del borde al pasar el mouse */
  }
  .imgP {
  
    max-width: 94%;
    height: auto;
    border-radius: 10px;
    border: 3px solid transparent; /* Asegura que haya espacio para el borde */
    transition: transform 0.3s ease;  /* Transición suave para el agrandamiento */
    filter: grayscale(60%) sepia(30%) brightness(90%);
  }
  .imgP:hover {
    transform: scale(1.1);  /* Aumenta el tamaño al 105% del original */
    border-color: rgba(0, 0, 0, 0.5); /* Color y opacidad del borde al pasar el mouse */
  }
  
  
  .imgP3 {
  
  max-width: 94%;
  height: 50%;
  border-radius: 10px;
  border: 3px solid transparent; /* Asegura que haya espacio para el borde */
  transition: transform 0.3s ease;  /* Transición suave para el agrandamiento */
  background-color: rgb(51, 0, 0); /* Color rojizo oscuro */
  filter: brightness(80%); /* Ajusta la luminosidad según sea necesario */
  }
  .imgP3:hover {
  transform: scale(1.1);  /* Aumenta el tamaño al 105% del original */
  border-color: rgba(0, 0, 0, 0.5); /* Color y opacidad del borde al pasar el mouse */
  }
  
  .imgP4 {
    max-width: 10%;
    height: auto;
    border-radius: 10px;
    border: 3px solid transparent; /* Asegura que haya espacio para el borde */
    transition: transform 0.3s ease, filter 0.3s ease; /* Añade la propiedad filter a la transición */
  }
  
  /* Agrega filtro blanco */
  .imgP4 {
    filter: brightness(70%) grayscale(100%);
  }
  .imgP4:hover {
    transform: scale(1.1); /* Aumenta el tamaño al 105% del original */
    filter: brightness(100%) grayscale(0%); /* Elimina el filtro al hacer hover */
  }
  
  .bttn2 {
    position: relative;
    background-color: rgba(128, 0, 0, 0.87);
    color: #fff;
    border: none;
    border-radius: 20px;
    padding: 10px 20px;
    cursor: pointer;
    transition: background-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
  }
  
  .bttn2:hover {
    background-color: rgba(150, 0, 0, 1);
    box-shadow: 0 0 10px rgba(229, 255, 0, 0.8);
    transform: scale(1.1); /* Aumenta el tamaño al pasar el mouse */
  }
  .center-div3 {
        display: flex;
        flex-direction: column;
        align-items: center; /* Centra los elementos horizontalmente */
        height: 100%;
      }
  
      .arriba {
        margin-bottom: 10px; /* Espaciado entre "arriba" y "divs-abajo" */
      }
  
      .divs-abajo {
        display: flex;
        width: 100%;
      }
  
      .abajo {
        
        background-color:rgba(36, 10, 10, 0.87);;
        flex: 1;
      margin: 2%;
        border: 0px solid #2e0505; /* Borde para visualizar mejor cada "abajo" */
  
        transition: transform 0.3s ease; /* Transición para el zoom al pasar el mouse */
  
      }
  
      .abajo:last-child {
        margin-right: 0; /* Elimina el margen derecho del último "abajo" para evitar espacio extra */
      }
  
      .abajo:hover {
        transform: scale(1.1); /* Efecto de zoom al pasar el mouse */
      }
  
      .contact-form {
    max-width: 400px;
    margin: 0 auto;
  }
  
  .form-group {
    margin-bottom: 20px;
  }
  
  .form-control {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  .footer {
      background-color: rgba(0, 0, 0, 0.808);
      color: #fff;
      padding: 20px 0;
  }
  
  .container {
      width: 80%;
      margin: 0 auto;
  }
  
  .footer-content {
      text-align: center;
  }
  
  table {
          border-collapse: collapse;
          width: 100%;
      }
  
      th, td {
      border: 1px solid rgba(36, 10, 10, 0.871);
      padding: 8px;
      text-align: left;
      max-width: 200px; /* Puedes ajustar este valor según tus necesidades */
      word-wrap: break-word; /* Opcional: overflow-wrap: break-word; */
      }
      th {
          background-color: rgba(36, 10, 10, 0.871);
          color: white;
  
      }
  
      /* Efecto de iluminación al pasar el mouse */
      td:hover, th:hover {
          background-color: rgba(255, 255, 255, 0.1);
      }
  </style>
  
  <style scoped>
  
  
      @media (max-width: 767px) {
          .center-div {
          width: 100%;
          max-width: 400px;
          margin: auto;
          margin-top: 20px;
          border-radius: 10px;
          background-color: rgba(36, 10, 10, 0.871);
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 20px;
          box-sizing: border-box;
          margin-bottom: 20px;
          }
  
          .izquierda {
          margin: 10px;
          }
  
          .derecha {
          width: 100%;
          margin-top: 10px;
          margin-right: 0;
          }
  
          .imgP {
          max-width: 100%;
          height: auto;
          border-radius: 10px;
          border: 3px solid transparent;
          transition: transform 0.3s ease;
          background-color: rgba(247, 244, 244, 0.87);
          filter: brightness(80%);
          }
  
          .imgP:hover {
          transform: scale(1.1);
          border-color: rgba(0, 0, 0, 0.5);
          }
      }
    </style>
  
  <style>
      @media (max-width: 767px) {
          .center-div2 {
              width: 100%;
              max-width: 400px;
              margin: auto;
              margin-top: 20px;
              border-radius: 10px;
              background-color: rgba(36, 10, 10, 0.871);
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              padding: 20px;
              box-sizing: border-box;
              margin-bottom: 20px;
          }
          .izquierda {
              display: none;
          }
          .derecha {
              width: 100%;
              margin-top: 10px;
              margin-right: 0;
          }
          .imgP1 {
              max-width: 100%;
              height: auto;
              border-radius: 10px;
              border: 3px solid transparent;
              transition: transform 0.3s ease;
              background-color: rgba(247, 244, 244, 0.87);
              filter: brightness(80%);
          }
  
          .imgP1:hover {
              transform: scale(1.1);
              border-color: rgba(0, 0, 0, 0.5);
          }
  
          .center-div2 h1,
          .center-div2 h2,
          .center-div2 p {
              text-align: center;
          }
      }
  
  
  </style>
  
  <style>
      .Moviles{
          display: none;
      }
      @media (max-width: 767px) {
          .nomovil{
          display: none;
          }
          .Moviles{
          display: flex;
          }
          .center-div3 {
              width: 100%;
              max-width: 400px;
              margin: auto;
              margin-top: 20px;
              border-radius: 10px;
              background-color: rgba(36, 10, 10, 0.871);
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              padding: 20px;
              box-sizing: border-box;
              margin-bottom: 20px;
          }
  
      }
  
  
  </style>
  
  <style>
@keyframes fireAnimation {
  0% {
    color: red;
    text-shadow: 0 0 10px yellow, 0 0 20px orange, 0 0 30px red;
  }
  50% {
    color: orange;
    text-shadow: 0 0 15px yellow, 0 0 25px red, 0 0 35px orange;
  }
  100% {
    color: yellow;
    text-shadow: 0 0 20px orange, 0 0 30px red, 0 0 40px yellow;
  }
}

.sendEmail {
    margin-left: 20%;
    background-color: black;
    text-align: center;
    display: none;
    animation: fireAnimation 2s linear infinite;
    width: 60%
}
  </style>
  <?php /**PATH C:\xampp\htdocs\SoftwareSouls\resources\views/Principal/SoftwareSouls.blade.php ENDPATH**/ ?>