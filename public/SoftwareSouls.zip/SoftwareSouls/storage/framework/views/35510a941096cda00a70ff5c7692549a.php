<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title>Herramientas</title>
    <script>
        window.confirmarEliminacion = function(url) {
        if (confirm('¿Estás seguro de que deseas eliminar esta herramienta?')) {
            window.location.href = url;
        }
        };
    </script>
</head>
<body>
    <?php echo $__env->yieldPushContent('scripts-bottom'); ?>
    <?php echo $__env->make('Administrador/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form action="<?php echo e(url('/subirHerramienta')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <br>Nombre Herramienta<br>
        <input type="text" name="NombreHerramienta" value="<?php echo e(old('NombreHerramienta')); ?>" placeholder="Nombre de la herramienta">
        <br>Descripcion de la herramienta<br>
        <input type="text" name="DescripcionH" value="<?php echo e(old('DescripcionH')); ?>" placeholder="Descripcion de la herramienta">
        <br>Fotografía Herramienta <br>
        <input type="file" name="Fotografia" accept=".png, .jpg">
        <br>
        <button type="submit">Registrar</button>
        <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors ->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($error); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    </form>



    <table>
        <thead>
            <tr>
                <th>Nombre de la Herramienta</th>
                <th>Descripción</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $Herramientas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Herramienta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($Herramienta->NombreHerramienta); ?></td>
                    <td><?php echo e($Herramienta->DescripcionH); ?></td>
                    <td>
                        <?php if($Herramienta->Fotografia): ?>
                            <img src="data:image/png;base64,<?php echo e(base64_encode($Herramienta->Fotografia)); ?>" alt="Fotografia" style="max-width: 100px;">
                        <?php else: ?>
                            <p>No hay imagen disponible</p>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('modificarHerramienta', ['id' => $Herramienta->ID_Herramientas])); ?>">Modificar</a>
                        <button onclick="confirmarEliminacion('<?php echo e(route('eliminarHerramienta', ['id' => $Herramienta->ID_Herramientas])); ?>')">Eliminar</button>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<style>
    form {
        color: white;
        max-width: 400px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #4b1111;
        border-radius: 5px;
        background-color: rgba(36, 10, 10, 0.871);
    }

    form input[type="text"],
    form input[type="file"],
    form button {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        box-sizing: border-box;
    }

    form button {
        background-color: #4b0c0c;
        color: rgb(255, 255, 255);
        border: none;
        border-radius: 5px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    form button:hover {
        background-color: #792727cc;
    }
    table {
        border-collapse: collapse;
        width: 100%;
        max-width: 800px;
        margin: 0 auto;
        background-color: #3B0C0C; /* Rojo oscuro */
        color: #FFFFFF; /* Blanco */
    }

    th, td {
        border: 1px solid #8B0000; /* Burdeos oscuro */
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #8B0000; /* Burdeos oscuro */
    }

    tr:nth-child(even) {
        background-color: #4F0A0A; /* Rojo oscuro más claro */
    }

    img {
        max-width: 100px;
    }


    button {
        color: #FFFFFF; /* Blanco */
        background-color: #8B0000; /* Burdeos oscuro */
        border: 1px solid #8B0000; /* Burdeos oscuro */
        border-radius: 4px;
        padding: 2px 8px;
        cursor: pointer;
    }

    button:hover {
        background-color: #A52A2A; /* Rojo oscuro más claro */
    }

</style>
<?php /**PATH C:\xampp\htdocs\SoftwareSouls\resources\views/Administrador/CRUD/Herramientas/Herramientas.blade.php ENDPATH**/ ?>